import {Component} from '@angular/core';

declare const $:any;
declare const kendo: any;
@Component({
    selector: 'org-teleric',
    templateUrl: './org-teleric.component.html',
    styleUrls: ['./org-teleric.component.styl']
})
export class OrgTelericComponent {

    ngOnInit()
    {
        this.fetchChart();
    }
    fetchChart()
    {
        var data = [{
            firstName: "Antonio",
            lastName: "Moreno",
            image:"https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTZuV7ul4BVf67jxqpRQ1So9aELaoRlswDnFhd474n2o1Lwud-I",
            title: "Team Lead",
            colorScheme: "#1696d3",
            items: [{
                firstName: "Elizabeth",
                image: "https://balkangraph.com/js/img/1.jpg",
                lastName: "Brown",
                title: "Design Lead",
                colorScheme: "#ef6944",
                items: [{
                    firstName: "Ann",
                    lastName: "Devon",
                    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRVovaMrWggrL5ZDVCMG1YUfNcL_PaRTocLVk0lTrHZahFZzVjn",
                    title: "UI Designer",
                    colorScheme: "#ef6944"
                }]
            }, {
                firstName: "Diego",
                lastName: "Roel",
                image: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRVovaMrWggrL5ZDVCMG1YUfNcL_PaRTocLVk0lTrHZahFZzVjn",
                title: "QA Engineer",
                colorScheme: "#ee587b",
                items: [{
                    firstName: "Fran",
                    lastName: "Wilson",
                    image: "https://balkangraph.com/js/img/5.jpg",
                    title: "QA Intern",
                    colorScheme: "#ee587b"
                }]
            }, {
                firstName: "Felipe",
                lastName: "Izquiedro",
                image: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRVovaMrWggrL5ZDVCMG1YUfNcL_PaRTocLVk0lTrHZahFZzVjn",
                title: "Senior Developer",
                colorScheme: "#75be16",
                items: [{
                    firstName: "Daniel",
                    lastName: "Tonini",
                    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRVovaMrWggrL5ZDVCMG1YUfNcL_PaRTocLVk0lTrHZahFZzVjn",
                    title: "Developer",
                    colorScheme: "#75be16"
                }]
            }]
        }];

        function visualTemplate(options) {
            var dataviz = kendo.dataviz;
            var g = new dataviz.diagram.Group();
            var dataItem = options.dataItem;

            g.append(new dataviz.diagram.Rectangle({
                width: 210,
                height: 75,
                stroke: {
                    width: 0
                },
                fill: {
                    gradient: {
                        type: "linear",
                        stops: [{
                            color: dataItem.colorScheme,
                            offset: 0,
                            opacity: 0.5
                        }, {
                            color: dataItem.colorScheme,
                            offset: 1,
                            opacity: 1
                        }]
                    }
                }
            }));

            g.append(new dataviz.diagram.TextBlock({
                text: dataItem.firstName + " " + dataItem.lastName,
                x: 85,
                y: 20,
                fill: "#fff"
            }));

            g.append(new dataviz.diagram.TextBlock({
                text: dataItem.title,
                x: 85,
                y: 40,
                fill: "#fff"
            }));

            g.append(new dataviz.diagram.Image({
                source: dataItem.image,
                x: 3,
                y: 3,
                width: 68,
                height: 68
            }));

            return g;
        }

        function createDiagram() {
            $("#diagram").kendoDiagram({
                dataSource: new kendo.data.HierarchicalDataSource({
                    data: data,
                    schema: {
                        model: {
                            children: "items"
                        }
                    }
                }),
                layout: {
                    type: "layered"
                },
                shapeDefaults: {
                    visual: visualTemplate
                },
                connectionDefaults: {
                    stroke: {
                        color: "#979797",
                        width: 2
                    }
                }
            });

            var diagram = $("#diagram").getKendoDiagram();
            diagram.bringIntoView(diagram.shapes);
        }

        $(document).ready(createDiagram);
    }
}
